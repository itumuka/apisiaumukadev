<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddNoSuratTugasToAkdSkripsiSkTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('akd_skripsi_sk', function (Blueprint $table) {
            if (!Schema::hasColumn('akd_skripsi_sk', 'no_surat_tugas')) {
                $table->string('no_surat_tugas', 100)->nullable()->after('no_sk');
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('akd_skripsi_sk', function (Blueprint $table) {
            if (Schema::hasColumn('akd_skripsi_sk', 'no_surat_tugas')) {
                $table->dropColumn('no_surat_tugas');
            }
        });
    }
}
